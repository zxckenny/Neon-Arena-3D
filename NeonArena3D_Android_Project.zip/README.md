# Neon Arena 3D

A small, fictional sci-fi arcade shooter prototype for Android. The player moves around a neon arena and tags floating training drones. It is a game prototype, not a realistic weapon simulator.

## Build APK on GitHub
1. Create a GitHub repository and upload the **contents** of this folder to its root (including the hidden `.github` folder).
2. Open Actions → Build Neon Arena APK → Run workflow.
3. Download `Neon-Arena-3D-APK` from the successful run's Artifacts.
4. Extract the artifact ZIP and install `app-debug.apk`.

The game uses Three.js from a CDN, so the device needs an internet connection when playing.
